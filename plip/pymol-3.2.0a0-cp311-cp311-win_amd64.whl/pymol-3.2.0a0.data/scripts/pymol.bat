"X:\Python311\python.exe" "X:\Python311\Lib\site-packages\pymol\__init__.py" %*
